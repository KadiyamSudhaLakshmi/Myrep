import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { DemoComponent } from './demo/demo.component';
import { BasicComponent } from './basic/basic.component';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { PipedemoComponent } from './pipedemo/pipedemo.component';
import { OrderComponent } from './order/order.component';
import { GenderPipe } from './order/gender.pipe';
import { OrderbyPipe } from './order/orderby.pipe';
import { ServiceComponent } from './service/service.component';
import { MyfilterComponent } from './myfilter/myfilter.component';
import { OrderPipe } from './myfilter/order.pipe';
import { ShowpersonDirective } from './Directives/showperson.directive';
import { PersonComponent } from './Component/person/person.component';
import { TemplateComponent } from './template/template.component';
import { AppRoutingModule } from './app/app-routing.module';
import { Routes,RouterModule, Router } from '@angular/router'
import { from } from 'rxjs';

@NgModule({
  declarations: [
    AppComponent,
    DemoComponent,
    BasicComponent,
    PipedemoComponent,
    OrderComponent,
    GenderPipe,
    OrderbyPipe,
    ServiceComponent,
    MyfilterComponent,
    OrderPipe,
    ShowpersonDirective,
    PersonComponent,
    TemplateComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule,
    RouterModule,
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
