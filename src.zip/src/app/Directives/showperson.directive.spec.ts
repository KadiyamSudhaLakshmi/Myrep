import { ShowpersonDirective } from './showperson.directive';

describe('ShowpersonDirective', () => {
  it('should create an instance', () => {
    const directive = new ShowpersonDirective();
    expect(directive).toBeTruthy();
  });
});
