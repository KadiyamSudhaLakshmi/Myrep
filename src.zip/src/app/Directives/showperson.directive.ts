import { Directive,Input, TemplateRef, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[appShowperson]'
})
export class ShowpersonDirective {
  @Input() 
  set appShowPerson(age:number){
    if(age>50){
      let view=this.viewContainer.createEmbeddedView(this.template);
      view.rootNodes[0].style.display="block";
      view.rootNodes[0].style.borderStyle="solid";
      view.rootNodes[0].style.borderColor="red";
      view.rootNodes[0].style.width=2;
      view.rootNodes[0].style.textSize=20;
  
  
    }
    else{
        this.viewContainer.clear();
    }
  }
  
    constructor
    (
     // private template:TemplateRef<any>,
      //private viewContainer:ViewContainerRef
      private template:TemplateRef<any>,
      private viewContainer:ViewContainerRef
    )
     { }
  
  }
  