import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MydateService {
today:Date;
  constructor() { }
  getDateService():any{
    return this.today;
  }
}
