import { Component, OnInit } from '@angular/core';
import { MydateService } from './mydate.service';
import { EmpService } from './emp.service';

@Component({
  selector: 'app-service',
  templateUrl: './service.component.html',
  styleUrls: ['./service.component.css'],
  providers:[MydateService,EmpService]
})
export class ServiceComponent implements OnInit {
today:Date;
employee:any;
  constructor(private m :MydateService,private e :EmpService) {

   }
   show(){
     this.getDate();
   }
   getDate(){
     this.today=this.m.getDateService();
     this.employee=this.e.getEmpService();
   }
  ngOnInit(): void {
  }

}
