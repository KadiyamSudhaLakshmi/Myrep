import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmpService {
emp=[
  {id:101,fname:"Sudha"},
  {id:101,fname:"Sudha"},
  {id:101,fname:"Sudha"},
  {id:101,fname:"Sudha"},
  {id:101,fname:"Sudha"},
]
  constructor() { }
  getEmpService():any{
    return this.emp;
  }
}
