import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'gender'
})
export class GenderPipe implements PipeTransform {

  transform(value: any): any {
    switch(value)
    {
      case 1:return "male"
      case 2:return "female"
      case 3:"others"
    }
  }


}
