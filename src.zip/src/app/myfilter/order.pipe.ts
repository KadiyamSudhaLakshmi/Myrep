import { Pipe, PipeTransform } from '@angular/core';
import { OrderbyPipe } from '../order/orderby.pipe';
@Pipe({
  name: 'order'
})
export class OrderPipe implements PipeTransform {

  transform(value: Array<any>): any {
    value.sort((a,b)=>{
      if(a.id>b.id) return a;
      else  return b;
    });
  }
}
