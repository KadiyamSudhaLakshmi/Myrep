import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyfilterComponent } from './myfilter.component';

describe('MyfilterComponent', () => {
  let component: MyfilterComponent;
  let fixture: ComponentFixture<MyfilterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyfilterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyfilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
