import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipedemo',
  templateUrl: './pipedemo.component.html',
  styleUrls: ['./pipedemo.component.css']
})
export class PipedemoComponent implements OnInit {
  name="Manisha";
  loc="pune";
  cmp="atos syntel pvt ltd";
  sal=12345.67899;
  doj=new Date();
  emp={fname:'sam',loc:"chennai"}
    constructor() { }
  
    ngOnInit() {
    }
  
  }