import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {ChildComponent} from '../child/child.component';
import {ParentComponent} from '../parent/parent.component';
import {BasicComponent} from '../basic/basic.component';
import {DemoComponent} from '../demo/demo.component';
import {MyfilterComponent} from '../myfilter/myfilter.component';
import {OrderComponent} from '../order/order.component';
import {PipedemoComponent} from '../pipedemo/pipedemo.component';
import {ServiceComponent} from '../service/service.component';
import {TemplateComponent} from '../template/template.component';

import { from } from 'rxjs';

const routes: Routes = [
  {path:"Child",component:ChildComponent},
  {path:"Parent",component:ParentComponent},
{path:"Basic",component:BasicComponent},
{path:"Demo",component:DemoComponent},
{path:"MyFilter",component:MyfilterComponent},
{path:"Order",component:OrderComponent},
{path:"Pipe",component:PipedemoComponent},
{path:"Service",component:ServiceComponent},
{path:"Template",component:TemplateComponent},
{path:"**",redirectTo:"Child"},
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
