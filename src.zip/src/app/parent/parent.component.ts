import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.scss']
})
export class ParentComponent implements OnInit {


  message="I am Parent";

  childMessage="";
  company="Atos Syntel Pvt Ltd";
  employee:any;
emp=[
  {id:101,name:'Manisha'},{id:102,name:'Swati'}
]

  constructor() { }

  ngOnInit() {
  }

  deleteEmp(e: any){

    let idx = this.emp.indexOf(e);
    console.log(idx);
    this.emp.splice(idx,1);
 //  this.empList = this.empList.filter((empl)=>{return empl.empNo != emp.empNo})
 }


}
