import { Component, OnInit,Input,Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.scss']
})
export class ChildComponent implements OnInit {

  constructor() { }
  @Input()
  parentMessage="";
  @Input()
  cmp="";
  @Input()
  emp:any;
//registered the event 
  @Output()
childChanged=new EventEmitter<string>();
@Output()
remove=new EventEmitter<string>();

message="I am child!!!";

sendMessageToParent(){
  this.childChanged.emit(this.message);
  console.log("In sendMessageToParent......");
   }
 
  ngOnInit() {
  }

  
  onDelete(){
    console.log('in delete')
   // this.emp.slice(this.emp.id,1)
     this.remove.emit(this.emp);
   }



}
