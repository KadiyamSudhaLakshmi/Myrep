import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic',
  templateUrl: './basic.component.html',
  styleUrls: ['./basic.component.css']
})
export class BasicComponent implements OnInit {
  title='Angular Basics';

 
  day=1;
  
  min=1;  
  
  name={"fname":"Manisha","lname":"Kiran"};
  
  show=true;
  
  hide=false;
  constructor() {
    console.log("AngularBasicsComponent created...");
    
       }
    
      ngOnInit() {
        console.log("AngularBasicsComponent initialized...");
    
      }
      ngOnDestroy() {
        console.log("AngularBasicsComponent destroyed...");
    
      }
    
      showHide(){
       this.hide=!this.hide; 
      }

}

