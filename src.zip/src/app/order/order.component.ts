import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {
  title:"My Pipe"
  row:3
  emp=[{id:100,name:'Janu',sal:25000,loc:'Chennai',date:new Date(),gender:1},
    {id:101,name:'Chinnu',sal:30000,loc:'Vizag',date:new Date(),gender:1},
    {id:102,name:'Madhu',sal:27000,loc:'Vizag',date:new Date(),gender:1},
    {id:103,name:'Hema',sal:45000,loc:'Mumbai',date:new Date(),gender:1},
    {id:104,name:'pavani',sal:37000,loc:'Dubai',date:new Date(),gender:1},
    {id:105,name:'Guna',sal:29000,loc:'Hyderabad',date:new Date(),gender:1},
    {id:106,name:'Sudha',sal:20000,loc:'Chennai',date:new Date(),gender:1},
    {id:107,name:'ram',sal:500000,loc:'England',date:new Date(),gender:1},
    {id:108,name:'Kali',sal:47000,loc:'Kolkata',date:new Date(),gender:1}
    ];

  constructor() { }

  ngOnInit(): void {
  }

}
