package com.Mod3.ex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mymod3ExApplicationTests {

	@Test
	void contextLoads() {
	}

}
