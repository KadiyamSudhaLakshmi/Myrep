package com.Mod3.ex.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.Mod3.ex.model.Trainings;

@Repository
public class TrainingDaoImpl implements TrainingDao {

	@Autowired
	private EntityManager entityManager;
	
	@Override
	public List<Trainings> get() {
		Session currentSession = entityManager.unwrap(Session.class);
		Query<Trainings> query = currentSession.createQuery("from Trainings", Trainings.class);
		List<Trainings> list = query.getResultList();
		return list;
	}

	@Override
	public Trainings get(int id) {
		Session currentSession = entityManager.unwrap(Session.class);
		Trainings trainingobj = currentSession.get(Trainings.class,id);
		return trainingobj;
	}

	@Override
	public void save(Trainings trainings) {
		Session currentSession = entityManager.unwrap(Session.class);
		currentSession.saveOrUpdate(trainings);
	}

	@Override
	public void delete(int id) {
		Session currentSession = entityManager.unwrap(Session.class);
		Trainings trainingobj = currentSession.get(Trainings.class, id);
		currentSession.delete(trainingobj);
		
	}

	
}
