package com.Mod3.ex.service;

import java.util.List;

import com.Mod3.ex.model.Trainings;

public interface TrainingService {
	
	List<Trainings> get();
	
	Trainings get(int id);
	
	void save(Trainings trainings);
	
	void delete(int id);
	

}
