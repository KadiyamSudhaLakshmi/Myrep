package com.Mod3.ex.controller;

//import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.Mod3.ex.model.Trainings;
import com.Mod3.ex.service.TrainingService;


@Controller
public class TrainingController {

	
	@Autowired
	private TrainingService trainingservice;

	
//	@GetMapping("/")
//	public List<Trainings> get(){
//		return trainingservice.get();
//	}
	
	@RequestMapping("/trainings")
	public ModelAndView get() {
		ModelAndView mav = new ModelAndView("list");
		mav.addObject("list",trainingservice.get());	
		return mav;
	}
	
	@RequestMapping(value= {"/home","/"})
	public String home() {
		return "home";
	}
	
	@RequestMapping("/view")
	public String view() {
		return "view";
	}
	@RequestMapping("/feedback")
	public String feedback() {
		return "feedback";
	}
	@RequestMapping("/assesment")
	public String Assesment() {
		return "assesment";
	}
	@RequestMapping("/show")
	public ModelAndView show() {
		ModelAndView mav = new ModelAndView("addtraining");
		mav.addObject("training", new Trainings());
		return mav;
	}
	
	@RequestMapping("/save")
	public ModelAndView save(@ModelAttribute("training") Trainings trainingobj) {
		ModelAndView mav = new ModelAndView("list");
		trainingservice.save(trainingobj);
		mav.addObject("list", trainingservice.get());
		return mav;
	}
	
	@RequestMapping("/update")
	public ModelAndView get(@RequestParam("id") int id) {
		ModelAndView mav = new ModelAndView("addtraining");
		Trainings trainingobj = trainingservice.get(id);
		if(trainingobj == null) {
			throw new RuntimeException("Training not found");
		}
		mav.addObject("training", trainingobj);
		return mav;
	}
	
	@RequestMapping("/delete")
	public ModelAndView delete(@RequestParam("id") int id) {
		ModelAndView mav = new ModelAndView("list");
		trainingservice.delete(id);
		mav.addObject("list", trainingservice.get());
		return mav;
		}
	
	//@PutMapping("/Trainings")
	//public Trainings update(@RequestBody Trainings trainingobj) {
	//	trainingservice.save(trainingobj);
		//return trainingobj;
	//}
}