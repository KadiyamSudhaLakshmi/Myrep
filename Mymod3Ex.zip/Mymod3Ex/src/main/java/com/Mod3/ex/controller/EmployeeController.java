package com.Mod3.ex.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
//import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.Mod3.ex.model.Employee;
import com.Mod3.ex.service.EmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	private EmployeeService employeeservice;
	@RequestMapping("/viewemp")
	public String view() {
		return "viewemp";
	}
	
	
	//@RequestMapping("/employeeid")
	//public ModelAndView get(@RequestParam("id") int trainingid){
	//	ModelAndView mav = new ModelAndView("emplist");
	//	List<Employee> empobj = employeeservice.get(trainingid);
	//	if(empobj == null) {
	//		throw new RuntimeException("Employee not found");
	//	}
	//	mav.addObject("employee", empobj);
	//	return mav;
	//}
	
	@RequestMapping("/employee")
	public ModelAndView get() {
		ModelAndView mav = new ModelAndView("emplist");
		mav.addObject("list",employeeservice.get());
		return mav;
	}
	
	@RequestMapping("/showemp")
	public ModelAndView show() {
		ModelAndView mav = new ModelAndView("addemp");
		mav.addObject("employee", new Employee());
		return mav;
	}
	@RequestMapping("/saveemp")
	public ModelAndView saveemp(@ModelAttribute("employee") Employee empobj) {
		ModelAndView mav = new ModelAndView("emplist");
		employeeservice.save(empobj);
		mav.addObject("list",employeeservice.get());
		return mav;
	}
	
	@RequestMapping("/updateemp")
	public ModelAndView update(@RequestParam("id") int id) {
		ModelAndView mav = new ModelAndView("addemp");
		Employee empobj = employeeservice.get(id);
		if(empobj == null) {
			throw new RuntimeException("Employee not found");
		}
		mav.addObject("employee", empobj);
		return mav;
	}
	@RequestMapping("/deleteemp")
	public ModelAndView delete(@RequestParam("id") int id) {
		ModelAndView mav = new ModelAndView("emplist");
		employeeservice.delete(id);
		mav.addObject("list", employeeservice.get());
		return mav;
		}
}