package com.Mod3.ex.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="employee")
public class Employee {
	@Id
	@Column
	private Integer id;
	@Column
	private String empname;
	@Column
	private Integer trainingid;
	@Column
	private Date doj;
	@Column 
	private Integer marks;
	@Column 
	private String feedback;
	
	
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public Integer getTrainingid() {
		return trainingid;
	}
	public void setTrainingid(Integer trainingid) {
		this.trainingid = trainingid;
	}
	public Date getDoj() {
		return doj;
	}
	public void setDoj(Date doj) {
		this.doj = doj;
	}
	public Integer getMarks() {
		return marks;
	}
	public void setMarks(Integer marks) {
		this.marks = marks;
	}
	public String getFeedback() {
		return feedback;
	}
	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", empname=" + empname + ", trainingid=" + trainingid + ", doj=" + doj
				+ ", marks=" + marks + ", feedback=" + feedback + "]";
	}
	
	
}
