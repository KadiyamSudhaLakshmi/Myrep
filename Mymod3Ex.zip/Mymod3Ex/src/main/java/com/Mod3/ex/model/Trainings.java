package com.Mod3.ex.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="trainings")
public class Trainings {
	@Id
	@Column
	private Integer id;
	@Column
	private String name;
	@Column
	private String trainerid;
	@Column
	private String trainername;
	@Column
	private String vertical;
	@Column
	private String mode;
	@Column
	private Date sdate;
	@Column
	private Date edate;
	@Column
	private String participants;
	@Column
	private String status;
	
	
	
	public String getParticipants() {
		return participants;
	}
	public void setParticipants(String participants) {
		this.participants = participants;
	}
	public Date getSdate() {
		return sdate;
	}
	public void setSdate(Date sdate) {
		this.sdate = sdate;
	}
	public Date getEdate() {
		return edate;
	}
	public void setEdate(Date edate) {
		this.edate = edate;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTrainerid() {
		return trainerid;
	}
	public void setTrainerid(String trainerid) {
		this.trainerid = trainerid;
	}
	public String getTrainername() {
		return trainername;
	}
	public void setTrainername(String trainername) {
		this.trainername = trainername;
	}
	public String getVertical() {
		return vertical;
	}
	public void setVertical(String vertical) {
		this.vertical = vertical;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "Trainings [id=" + id + ", name=" + name + ", trainerid=" + trainerid + ", trainername=" + trainername
				+ ", vertical=" + vertical + ", mode=" + mode + ", sdate=" + sdate + ", edate=" + edate
				+ ", participants=" + participants + ", status=" + status + "]";
	}
	
	
}
