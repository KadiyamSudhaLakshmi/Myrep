package com.Mod3.ex.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.Mod3.ex.dao.TrainingDao;
import com.Mod3.ex.model.Trainings;

@Service
public class TrainingServiceImpl implements TrainingService {
	
	@Autowired
	private TrainingDao trainingdao;

	@Transactional
	@Override
	public List<Trainings> get() {
		return trainingdao.get();
	}

	@Transactional
	@Override
	public Trainings get(int id) {
		return trainingdao.get(id);
	}

	@Transactional
	@Override
	public void save(Trainings trainings) {
		trainingdao.save(trainings);
		
	}

	@Transactional
	@Override
	public void delete(int id) {
		trainingdao.delete(id);
	}


	
}
