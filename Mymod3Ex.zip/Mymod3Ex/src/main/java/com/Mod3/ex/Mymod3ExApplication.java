package com.Mod3.ex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mymod3ExApplication {

	public static void main(String[] args) {
		SpringApplication.run(Mymod3ExApplication.class, args);
	}

}
